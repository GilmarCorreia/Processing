# MemStream
Implementation of a Memory-Stream for Arduino to test e.g. Serial communications using memory buffers (supports Read and write incl. prefilled Buffers)

## TODO
* Check "writeAllowed" vs Example
* finally write README
* add Library to ArduinoIDE :-)
